// 91porna 站源模块 · 小果影视 / 红果鉴 模块 API 1
//
//   列表  /comic/index/video?category={id}&page={n}
//   搜索  /comic/index/search?keyword={kw}
//   详情  /comic/index/avdetail?video_key={key}
//   播放  POST /api/videos/{mediaId}/playback → data.streams.main（HLS m3u8，带 auth_key）
//
// 模块函数必须同步。

const SITE = 'https://91porna.com';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const HEADERS = {
  'User-Agent': UA,
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
};

const CATEGORIES = [
  { id: 'new_update', name: '最近更新' },
  { id: 'now_hot', name: '当前最热' },
  { id: 'now_month_hot', name: '本月最热' },
  { id: 'original', name: '91原创' },
  { id: 'hd', name: '高清' },
  { id: 'ten_minutes', name: '10分钟以上' },
  { id: 'twenty_minutes', name: '20分钟以上' },
  { id: 'now_month_collect', name: '本月收藏' },
  { id: 'now_month_comment', name: '本月讨论' },
  { id: 'max_collect', name: '收藏最多' }
];

function clean(s) {
  return String(s == null ? '' : s)
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function req(o) {
  const headers = {};
  for (const k in HEADERS) headers[k] = HEADERS[k];
  if (o.referer) headers['Referer'] = o.referer;
  if (o.body) headers['Content-Type'] = 'application/json';
  const res = host.fetch({ method: o.method || 'GET', url: o.url, headers: headers, body: o.body });
  if (res.status === 403) throw new Error('91porna 拦了请求（403）');
  if (res.status < 200 || res.status >= 300) throw new Error('91porna 返回 HTTP ' + res.status);
  return res.body || '';
}

function getText(path, referer) {
  const url = path.indexOf('http') === 0 ? path : SITE + path;
  return req({ url: url, referer: referer || SITE + '/' });
}

function parseCards(html) {
  const out = [];
  const seen = {};
  const re = /<div class="video-item">/g;
  const starts = [];
  let m;
  while ((m = re.exec(html)) !== null) starts.push(m.index);
  for (let i = 0; i < starts.length; i++) {
    const chunk = html.substring(starts[i], i + 1 < starts.length ? starts[i + 1] : starts[i] + 3000);
    const href = chunk.match(/href="\/comic\/index\/(?:avdetail|detail)\?video_key=([0-9A-Za-z_\-]+)"/);
    if (!href) continue;
    const key = href[1];
    if (seen[key]) continue;
    seen[key] = 1;
    const img = chunk.match(/data-src="([^"]+)"/) || chunk.match(/src="(http[^"]+)"/);
    const alt = chunk.match(/alt="([^"]*)"/);
    const dur = chunk.match(/([0-9]{1,3}:[0-9]{2})/);
    out.push({
      sourceId: key,
      title: alt ? clean(alt[1]) : key,
      cover: img ? img[1].replace(/&amp;/g, '&') : '',
      duration: dur ? dur[1] : ''
    });
  }
  return out;
}

function toDrama(item) {
  const title = item.title || item.sourceId;
  return {
    id: host.dramaId(item.sourceId),
    source: host.source,
    sourceId: item.sourceId,
    title: title,
    name: title,
    desc: item.duration ? '时长 ' + item.duration : '',
    intro: '',
    cover: item.cover || '',
    totalEpisode: 1
  };
}

function detailPage(key) {
  const paths = ['/comic/index/avdetail?video_key=', '/comic/index/detail?video_key='];
  let lastErr = null;
  for (let i = 0; i < paths.length; i++) {
    const url = SITE + paths[i] + encodeURIComponent(key);
    try {
      const html = getText(paths[i] + encodeURIComponent(key));
      if (html.indexOf('data-video="') > 0) return { html: html, url: url };
      lastErr = new Error('详情页没有播放数据');
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error('详情页打不开');
}

module.exports = {
  validCategory(category) {
    return !category || category === 'new' || CATEGORIES.some(function (e) { return e.id === category; });
  },

  categories() {
    return CATEGORIES;
  },

  catalogPage(page, category) {
    if (!this.validCategory(category)) throw new Error('没有分类 ' + category);
    const n = Number(page || 1) < 1 ? 1 : Number(page || 1);
    const cate = (!category || category === 'new') ? 'new_update' : category;
    const path = '/comic/index/video?category=' + cate + '&page=' + n;
    const items = parseCards(getText(path)).map(toDrama);
    return { items: items, hasMore: items.length >= 10 };
  },

  search(page, query) {
    const kw = clean(query || '');
    if (!kw) return { items: [], hasMore: false };
    const html = getText('/comic/index/search?keyword=' + encodeURIComponent(kw));
    const items = parseCards(html).map(toDrama);
    return { items: items, hasMore: false };
  },

  detail(sourceId) {
    const key = String(sourceId || '').trim();
    if (!key) throw new Error('缺少 video_key');
    const d = detailPage(key);
    const html = d.html;

    const t = html.match(/<title[^>]*>([\s\S]*?)<\/title>/);
    let title = t ? clean(t[1]) : '';
    title = title.replace(/\s*-\s*91视频[\s\S]*$/, '').replace(/\s*-\s*91porna[\s\S]*$/, '').trim();
    if (!title) {
      const og = html.match(/property="og:title"[^>]+content="([^"]*)"/);
      title = og ? clean(og[1]) : key;
    }
    const cover = html.match(/property="og:image"[^>]+content="([^"]+)"/);
    const descM = html.match(/property="og:description"[^>]+content="([^"]*)"/);
    const media = html.match(/data-video="([0-9]+)"/);
    if (media) {
      try { host.cacheSet('media:' + key, media[1]); } catch (e) { /* ignore */ }
    }

    const drama = {
      id: host.dramaId(key),
      source: host.source,
      sourceId: key,
      title: title,
      name: title,
      desc: descM ? clean(descM[1]).substring(0, 120) : '',
      intro: '',
      cover: cover ? cover[1].replace(/&amp;/g, '&') : '',
      totalEpisode: 1
    };
    const chapter = {
      id: host.chapterId(key, 'video'),
      source: host.source,
      title: '正片',
      currentEpisode: 1,
      pageUrl: d.url,
      referer: d.url
    };
    return { drama: drama, chapters: [chapter] };
  },

  resolveMedia(task) {
    let key = '';
    const fromDrama = String((task && task.dramaId) || '').split(':');
    if (fromDrama.length >= 2) key = fromDrama[1];
    if (!key) {
      const fromChapter = String((task && task.chapter && task.chapter.id) || '').split(':');
      if (fromChapter.length >= 3) key = fromChapter[1];
    }
    if (!key) throw new Error('无法确定 video_key');

    let media = '';
    try { media = host.cacheGet('media:' + key) || ''; } catch (e) { media = ''; }
    let page = SITE + '/comic/index/avdetail?video_key=' + encodeURIComponent(key);
    if (!media) {
      const d2 = detailPage(key);
      page = d2.url;
      const m = d2.html.match(/data-video="([0-9]+)"/);
      if (m) media = m[1];
    }
    if (!media) throw new Error('找不到 media id');

    const raw = req({
      method: 'POST',
      url: SITE + '/api/videos/' + media + '/playback',
      referer: page,
      body: '{}'
    });
    let json;
    try { json = JSON.parse(raw); } catch (e) { throw new Error('播放接口返回的不是 JSON'); }
    const streams = (json && json.data && json.data.streams) || {};
    const url = streams.main || streams.hevc || streams.preview || '';
    if (!url) throw new Error('播放接口没给地址');

    return {
      url: url,
      referer: page,
      quality: 720,
      credentials: { referer: page, origin: SITE, userAgent: UA }
    };
  }
};
