// Taiav 内容源插件
// 数据来源：https://taiav.com 服务端渲染页面 + /api/getmovie 取流接口
// 站点语言路径固定使用简体中文 /cn

const siteBaseUrl = "https://taiav.com";
const webLang = "/cn";
const mediaScheme = "taiav://";
const tagPrefix = "tag:";
const categoryPrefix = "category:";
const hotsCategory = "hots";
const newsCategory = "news";
const detailTtlMs = 10 * 60 * 1000;
const categoryTtlMs = 6 * 60 * 60 * 1000;
const pageSize = 15;
const maxTagCategories = 54;
const hdType = "1280";
const userAgent =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

// 站点固定分区（与 /discover 页面的“大分类”一致）
const bigCategories = ["国产AV", "无码", "有码", "网红主播"];
const fixedCategories = [
  { id: hotsCategory, name: "热门榜单" },
  { id: newsCategory, name: "最新更新" },
];
const rankingBoards = {
  "taiav-week": { key: "week", name: "一周热门", label: "周榜" },
  "taiav-month": { key: "month", name: "月度热门", label: "月榜" },
  "taiav-year": { key: "year", name: "年度热门", label: "年榜" },
};
const groupNames = { week: "一周热门", month: "月度热门", year: "年度热门" };

// ---------------------------------------------------------------------------
// 基础工具
// ---------------------------------------------------------------------------

function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function message(error) {
  if (error === null || error === undefined) return "";
  if (typeof error === "string") return error;
  return String(error.message || error);
}

function firstNonEmpty() {
  for (let index = 0; index < arguments.length; index++) {
    const value = arguments[index];
    if (value !== null && value !== undefined && String(value).trim() !== "") {
      return String(value).trim();
    }
  }
  return "";
}

function cacheRead(key) {
  try {
    const raw = host.cacheGet(key);
    if (raw === null || raw === undefined || raw === "") return null;
    return JSON.parse(raw);
  } catch (error) {
    return null;
  }
}

function cacheWrite(key, value, ttlMs) {
  try {
    host.cacheSet(key, JSON.stringify(value), ttlMs);
  } catch (error) {}
}

function decodeEntities(text) {
  if (typeof text !== "string" || text.indexOf("&") < 0) return text || "";
  return text
    .replace(/&#(\d+);/g, (all, code) => String.fromCharCode(parseInt(code, 10)))
    .replace(/&#x([0-9a-fA-F]+);/g, (all, code) => String.fromCharCode(parseInt(code, 16)))
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&");
}

function absolute(address) {
  const text = String(address || "").trim();
  if (text === "") return "";
  if (/^https?:\/\//i.test(text)) return text;
  if (text.charAt(0) === "/") return siteBaseUrl + text;
  return siteBaseUrl + "/" + text;
}

// 统一取页面文本；fetchText 失败时退回 host.fetch 并显式带上浏览器 UA
function fetchBody(path, noCache) {
  const url = /^https?:\/\//i.test(path) ? path : siteBaseUrl + path;
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const response = host.fetchText({ url: url, referer: siteBaseUrl + "/", noCache: noCache === true || attempt > 0 });
      const body = response && typeof response.body === "string" ? response.body : "";
      if (body !== "") return body;
      lastError = new Error("空响应");
    } catch (error) {
      lastError = error;
    }
    try {
      const response = host.fetch({
        method: "GET",
        url: url,
        headers: { "User-Agent": userAgent, Accept: "text/html,application/json;q=0.9,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.9" },
        anyStatus: true,
        followRedirects: true,
        timeoutMs: 25000,
        limit: 8 * 1024 * 1024,
      });
      const body = response && typeof response.body === "string" ? response.body : "";
      if (response && response.status >= 400) {
        lastError = new Error("HTTP " + response.status);
        continue;
      }
      if (body !== "") return body;
    } catch (error) {
      lastError = error;
    }
  }
  throw new Error("Taiav 页面请求失败：" + message(lastError));
}

function parseJsonBody(body, what) {
  try {
    return JSON.parse(body);
  } catch (error) {
    throw new Error(what + "返回的不是接口数据");
  }
}

function notFoundPage(body) {
  return /<title>\s*404/i.test(body) || body.indexOf("頁面未找到") >= 0 || body.indexOf("页面未找到") >= 0;
}

// ---------------------------------------------------------------------------
// 列表页解析
// ---------------------------------------------------------------------------

function cardChunks(body) {
  const marker = 'class="movie-card"';
  const parts = body.split(marker);
  const chunks = [];
  for (let index = 1; index < parts.length; index++) {
    const head = parts[index - 1].slice(-600);
    // 仅保留当前卡片自身的开标签，避免把上一张卡片的 data-id 误当成本卡片
    const open = head.slice(Math.max(0, head.lastIndexOf("<div")));
    chunks.push({ head: open, body: parts[index].slice(0, 30000) });
  }
  return chunks;
}

function dramaFromCard(chunk, categoryName) {
  const head = chunk.head || "";
  if (head.indexOf("data-has-link") >= 0 && head.indexOf("data-id") < 0) {
    return null; // 广告位
  }
  let id = firstNonEmpty((head.match(/data-id=\s*'"?([0-9a-fA-F]{24})"?/) || [])[1]);
  if (id === "") {
    id = firstNonEmpty((chunk.body.match(/\/movie\/([0-9a-fA-F]{24})/) || [])[1]);
  }
  if (id === "") return null;
  const title = decodeEntities(
    firstNonEmpty(
      (chunk.body.match(/data-full-title="([^"]*)"/) || [])[1],
      (chunk.body.match(/<img[^>]*alt="([^"]*)"/) || [])[1],
      id
    )
  );
  const cover = absolute(firstNonEmpty((chunk.body.match(/<img[^>]*src="([^"]+)"/) || [])[1]));
  const group = firstNonEmpty((head.match(/data-date="(\w+)"/) || [])[1]);
  const kind = decodeEntities(firstNonEmpty((chunk.body.match(/uk-tag uk-type[^>]*>([^<]*)</) || [])[1]));
  const item = {
    id: host.dramaId(id),
    source: host.source,
    sourceId: id,
    title: title,
    name: title,
    cover: cover,
    coverUrl: cover,
    desc: "",
    intro: "",
    tags: categoryName ? [categoryName] : [],
    categoryName: firstNonEmpty(categoryName, groupNames[group], kind),
    channelName: "Taiav",
  };
  if (groupNames[group]) {
    item.remark = groupNames[group];
  } else if (kind !== "") {
    item.remark = kind;
  }
  return item;
}

// scope = "global" 时整页去重（合并多榜单用）；"group" 时每个榜单内部去重（单榜单取值用）
function parseCards(body, categoryName, scope) {
  const seen = new Set();
  const items = [];
  for (const chunk of cardChunks(body)) {
    let drama = null;
    try {
      drama = dramaFromCard(chunk, categoryName);
    } catch (error) {
      drama = null;
    }
    if (drama === null) continue;
    drama.group = firstNonEmpty((chunk.head.match(/data-date="(\w+)"/) || [])[1]);
    const key = (scope === "group" ? drama.group + "|" : "") + drama.sourceId;
    if (seen.has(key)) continue;
    seen.add(key);
    items.push(drama);
  }
  return items;
}

function parseCardsByGroup(body, categoryName) {
  return parseCards(body, categoryName, "group");
}

function lastPageOf(body) {
  const pages = [];
  const pattern = /[?&]page=(\d+)/g;
  let match = pattern.exec(body);
  while (match !== null) {
    const value = parseInt(match[1], 10);
    if (!isNaN(value) && value > 0 && value < 100000) pages.push(value);
    match = pattern.exec(body);
  }
  if (pages.length === 0) return 0;
  return Math.max.apply(null, pages);
}

// ---------------------------------------------------------------------------
// 详情页解析
// ---------------------------------------------------------------------------

function parseVideoObject(body) {
  const index = body.indexOf('"VideoObject"');
  if (index < 0) return null;
  const start = body.lastIndexOf("{", index);
  const end = body.indexOf("}", index);
  if (start < 0 || end < 0) return null;
  try {
    return JSON.parse(body.slice(start, end + 1));
  } catch (error) {
    return null;
  }
}

function durationText(value) {
  const match = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(String(value || "").trim());
  if (match === null) return "";
  const hours = parseInt(match[1] || "0", 10);
  const minutes = parseInt(match[2] || "0", 10);
  const seconds = parseInt(match[3] || "0", 10);
  const parts = [];
  if (hours > 0) parts.push(hours + "小时");
  if (minutes > 0) parts.push(minutes + "分钟");
  if (hours === 0 && minutes === 0 && seconds > 0) parts.push(seconds + "秒");
  return parts.join("");
}

function parseDetail(body, id) {
  const video = parseVideoObject(body) || {};
  let title = firstNonEmpty(video.name);
  if (title === "") {
    const heading = body.match(/<h1[^>]*>([\s\S]*?)<\/h1>/);
    title = heading ? decodeEntities(heading[1].replace(/<[^>]+>/g, "")).trim() : "";
  }
  let desc = firstNonEmpty(video.description);
  if (desc === "") {
    const paragraph = body.match(/<p class="uk-margin-small-top">([\s\S]*?)<\/p>/);
    desc = paragraph ? decodeEntities(paragraph[1].replace(/<[^>]+>/g, "")).trim() : "";
  }
  desc = desc.replace(/video\s*info\s*source:[\s\S]*$/i, "").trim();
  const cover = absolute(firstNonEmpty(video.thumbnailUrl));
  const tags = [];
  const tagPattern = /href="\/[a-z]{2}\/tag\/([^"]+)"/g;
  let match = tagPattern.exec(body);
  while (match !== null) {
    let name = match[1];
    try {
      name = decodeURIComponent(name);
    } catch (error) {}
    name = decodeEntities(name).trim();
    if (name !== "" && tags.indexOf(name) < 0) tags.push(name);
    match = tagPattern.exec(body);
  }
  const onlineDate = firstNonEmpty(video.uploadDate);
  const time = firstNonEmpty((body.match(/<span class="time">([^<]*)<\/span>/) || [])[1]);
  return {
    title: firstNonEmpty(title, id),
    desc: desc,
    cover: cover,
    tags: tags,
    onlineDate: onlineDate,
    duration: durationText(video.duration),
    time: time,
  };
}

function normalizeId(value) {
  let text = String(value === null || value === undefined ? "" : value).trim();
  if (text.indexOf(mediaScheme) === 0) text = text.slice(mediaScheme.length);
  const movie = text.match(/\/movie\/([0-9a-fA-F]{24})/);
  if (movie !== null) return movie[1];
  const direct = text.match(/^([0-9a-fA-F]{24})$/);
  if (direct !== null) return direct[1];
  return "";
}

// ---------------------------------------------------------------------------
// 分类
// ---------------------------------------------------------------------------

function discoverTags() {
  const cached = cacheRead("categories");
  if (Array.isArray(cached) && cached.length > 0) return cached;
  const body = fetchBody(webLang + "/discover");
  const groups = body.split(/<h3[^>]*>/);
  const items = [];
  const seen = new Set();
  for (let index = 1; index < groups.length; index++) {
    const block = groups[index];
    const heading = (block.match(/^([^<]*)<\/h3>/) || [])[1] || "";
    const name = decodeEntities(heading).trim();
    if (name === "" || name === "女優" || name === "更多" || name === "大分类") continue;
    const pattern = /href="\/[a-z]{2}\/tag\/([^"]+)"/g;
    let match = pattern.exec(block);
    while (match !== null) {
      let tag = match[1];
      try {
        tag = decodeURIComponent(tag);
      } catch (error) {}
      tag = decodeEntities(tag).trim();
      if (tag !== "" && !seen.has(tag)) {
        seen.add(tag);
        items.push({ id: tagPrefix + tag, name: tag });
      }
      match = pattern.exec(block);
    }
  }
  if (items.length === 0) throw new Error("Taiav 分类标签为空");
  const trimmed = items.slice(0, maxTagCategories);
  cacheWrite("categories", trimmed, categoryTtlMs);
  return trimmed;
}

function categories(force) {
  const base = fixedCategories.concat(bigCategories.map((name) => ({ id: categoryPrefix + name, name: name })));
  if (force === true) {
    try {
      cacheWrite("categories", null, 0);
    } catch (error) {}
  }
  let tags;
  try {
    tags = discoverTags();
  } catch (error) {
    host.log("taiav.categories.failed " + JSON.stringify({ error: message(error) }));
    return { items: base, incomplete: true };
  }
  return base.concat(tags);
}

function validCategory(category) {
  const key = String(category === null || category === undefined ? "" : category);
  if (key === "" || key === hotsCategory || key === newsCategory) return true;
  if (key.indexOf(categoryPrefix) === 0) {
    return bigCategories.indexOf(key.slice(categoryPrefix.length)) >= 0;
  }
  if (key.indexOf(tagPrefix) === 0) return key.length > tagPrefix.length;
  return false;
}

// ---------------------------------------------------------------------------
// 目录（首页 / 分类 / 标签）
// ---------------------------------------------------------------------------

function catalogPath(page, category) {
  if (category === "" || category === newsCategory) {
    return { path: "/news?page=" + page, name: "最新更新", paged: true };
  }
  if (category === hotsCategory) {
    return { path: "/hots", name: "热门", paged: false };
  }
  if (category.indexOf(categoryPrefix) === 0) {
    const name = category.slice(categoryPrefix.length);
    if (bigCategories.indexOf(name) < 0) throw new Error("未知的 Taiav 分类");
    return { path: "/category/" + encodeURIComponent(name) + "?page=" + page, name: name, paged: true };
  }
  if (category.indexOf(tagPrefix) === 0) {
    const name = category.slice(tagPrefix.length);
    if (name === "") throw new Error("空的 Taiav 标签");
    return { path: "/tag/" + encodeURIComponent(name) + "?page=" + page, name: name, paged: true };
  }
  throw new Error("未知的 Taiav 分类");
}

function catalogPage(page, category) {
  let current = Math.max(1, parseInt(page, 10) || 1);
  const key = typeof category === "string" ? category : "";
  const target = catalogPath(current, key);
  const body = fetchBody(webLang + target.path);
  if (notFoundPage(body)) {
    if (current === 1) throw new Error("Taiav 分类不存在：" + target.name);
    return { items: [], hasMore: false, warning: "没有更多内容了" };
  }
  let items;
  if (!target.paged) {
    items = parseCardsByGroup(body, target.name);
  } else {
    items = parseCards(body, target.name);
  }
  const lastPage = target.paged ? lastPageOf(body) : 0;
  const hasMore = target.paged ? lastPage > current : false;
  return { items: items, hasMore: hasMore, warning: "" };
}

// ---------------------------------------------------------------------------
// 搜索 / 联想
// ---------------------------------------------------------------------------

function search(page, query) {
  const keyword = String(query === null || query === undefined ? "" : query).trim();
  const current = Math.max(1, parseInt(page, 10) || 1);
  if (keyword === "") return { items: [], hasMore: false, warning: "" };
  const path = webLang + "/search?q=" + encodeURIComponent(keyword) + (current > 1 ? "&page=" + current : "");
  const body = fetchBody(path);
  if (notFoundPage(body)) {
    return { items: [], hasMore: false, warning: current > 1 ? "没有更多搜索结果" : "没有找到相关影片" };
  }
  const items = parseCards(body, "搜索");
  const lastPage = lastPageOf(body);
  return { items: items, hasMore: lastPage > current, warning: "" };
}

function suggestions(query) {
  const keyword = String(query === null || query === undefined ? "" : query).trim().toLowerCase();
  if (keyword === "") return [];
  let tags = [];
  try {
    tags = discoverTags();
  } catch (error) {
    return [];
  }
  const result = [];
  for (const item of tags) {
    const name = item.name;
    if (name.toLowerCase().indexOf(keyword) >= 0) {
      result.push(name);
      if (result.length >= 10) break;
    }
  }
  return result;
}

// ---------------------------------------------------------------------------
// 详情 / 播放
// ---------------------------------------------------------------------------

function detail(sourceId) {
  const id = normalizeId(sourceId);
  if (id === "") throw new Error("无效的 Taiav 影片 ID");
  const cached = cacheRead("detail:" + id);
  let info = cached;
  if (info === null) {
    const body = fetchBody(webLang + "/movie/" + id);
    if (notFoundPage(body)) throw new Error("Taiav 影片不存在或已下架");
    info = parseDetail(body, id);
    if (info.title === "") throw new Error("Taiav 详情页结构异常");
    cacheWrite("detail:" + id, info, detailTtlMs);
  }
  const drama = {
    id: host.dramaId(id),
    source: host.source,
    sourceId: id,
    title: info.title,
    name: info.title,
    desc: info.desc,
    intro: info.desc,
    cover: info.cover,
    coverUrl: info.cover,
    tags: info.tags || [],
    categoryName: (info.tags || [])[0] || "",
    channelName: "Taiav",
    remark: info.duration || "",
    onlineDate: info.onlineDate || "",
  };
  const chapter = {
    id: host.chapterId(id, id),
    source: host.source,
    title: "正片",
    videoUrl: mediaScheme + id,
    currentEpisode: 1,
  };
  return { drama: drama, chapters: [chapter] };
}

function resolveMedia(task) {
  const chapter = (task && task.chapter) || {};
  const raw = String(chapter.videoUrl || "");
  if (raw === "") throw new Error("Taiav 章节不存在");
  if (raw.indexOf(mediaScheme) !== 0) {
    return host.finishMedia({ url: raw, referer: siteBaseUrl + "/" });
  }
  const id = normalizeId(raw.slice(mediaScheme.length));
  if (id === "") throw new Error("Taiav 章节 ID 无效");
  const referer = siteBaseUrl + webLang + "/movie/" + id;
  const body = fetchBody("/api/getmovie?type=" + hdType + "&id=" + encodeURIComponent(id), true);
  let result;
  try {
    result = parseJsonBody(body, "Taiav 播放接口");
  } catch (error) {
    if (notFoundPage(body)) throw new Error("Taiav 播放接口不可用，请稍后重试");
    throw error;
  }
  const address = firstNonEmpty(result && result.m3u8);
  if (address === "") {
    const reason = firstNonEmpty(result && result.message);
    throw new Error(reason === "" ? "Taiav 播放接口未返回播放地址" : "Taiav：" + reason);
  }
  host.log("taiav.playback.ready " + JSON.stringify({ id: id }));
  return host.finishMedia({ url: absolute(address), referer: referer });
}

// ---------------------------------------------------------------------------
// 榜单
// ---------------------------------------------------------------------------

function rankingPage(boardId, page) {
  const board = rankingBoards[boardId];
  if (!board) throw new Error("未知的 Taiav 榜单");
  const current = Math.max(1, parseInt(page, 10) || 1);
  if (current > 1) return { items: [], hasMore: false };
  const body = fetchBody(webLang + "/hots");
  if (notFoundPage(body)) throw new Error("Taiav 热门榜单不可用");
  const all = parseCardsByGroup(body, "热门");
  const picked = all.filter((drama) => drama.group === board.key);
  if (picked.length === 0) throw new Error("Taiav 榜单未返回任何影片");
  const items = picked.map((drama, index) => {
    const item = { rank: index + 1, drama: drama };
    item.metric = board.label;
    return item;
  });
  return { items: items, hasMore: false, updatedText: "每日更新" };
}

// ---------------------------------------------------------------------------
// 封面 / 补充元数据 / 目录状态
// ---------------------------------------------------------------------------

function coverAddress(drama, id) {
  if (drama && typeof drama.coverUrl === "string" && drama.coverUrl !== "") return absolute(drama.coverUrl);
  if (drama && typeof drama.cover === "string" && drama.cover !== "") return absolute(drama.cover);
  const key = normalizeId(id);
  if (key === "") return "";
  const cached = cacheRead("detail:" + key);
  if (cached !== null && cached.cover) return absolute(cached.cover);
  return "";
}

function needsExtraMetadata(drama) {
  if (!isRecord(drama)) return false;
  return !drama.desc || !drama.onlineDate;
}

function extraMetadata(drama, id) {
  const key = normalizeId(id) || normalizeId(drama && drama.sourceId);
  if (key === "") return null;
  try {
    const body = fetchBody(webLang + "/movie/" + key);
    if (notFoundPage(body)) return null;
    const info = parseDetail(body, key);
    cacheWrite("detail:" + key, info, detailTtlMs);
    const patch = { id: host.dramaId(key) };
    if (info.desc) {
      patch.desc = info.desc;
      patch.intro = info.desc;
    }
    if (info.onlineDate) patch.onlineDate = info.onlineDate;
    if (info.cover) {
      patch.cover = info.cover;
      patch.coverUrl = info.cover;
    }
    if (info.tags && info.tags.length > 0) {
      patch.tags = info.tags;
      patch.categoryName = info.tags[0];
    }
    if (info.duration) patch.remark = info.duration;
    return patch;
  } catch (error) {
    host.log("taiav.metadata.failed " + JSON.stringify({ id: key, error: message(error) }));
    return null;
  }
}

function catalogState() {
  return { version: 1, adapter: "taiav", updatedAt: new Date().toISOString() };
}

function restoreCatalogState(raw) {
  return null;
}

module.exports = {
  categories: categories,
  validCategory: validCategory,
  catalogPage: catalogPage,
  search: search,
  detail: detail,
  resolveMedia: resolveMedia,
  suggestions: suggestions,
  rankingPage: rankingPage,
  coverAddress: coverAddress,
  needsExtraMetadata: needsExtraMetadata,
  extraMetadata: extraMetadata,
  catalogState: catalogState,
  restoreCatalogState: restoreCatalogState,
};
