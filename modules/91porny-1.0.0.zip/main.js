// 91porny（九色）站源模块 · 小果影视 / 红果鉴 模块 API 1
//
//   列表  /{cate}?page={n}          cate: vod 精品 / video / videos / swag / madou
//   搜索  /search?keywords={kw}&page={n}
//   详情  /vod/view/{code}
//   播放  详情页 <video id="video-play" data-src="…index.m3u8">
//
// 模块函数必须同步。

const SITE = 'https://91porny.com';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const HEADERS = {
  'User-Agent': UA,
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
};

const CATEGORIES = [
  { id: 'vod', name: '精品' },
  { id: 'video', name: '视频' },
  { id: 'videos', name: '视频二' },
  { id: 'swag', name: 'SWAG' },
  { id: 'madou', name: '麻豆' }
];

function clean(s) {
  return String(s == null ? '' : s)
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function get(path, referer) {
  const url = path.indexOf('http') === 0 ? path : SITE + path;
  const headers = {};
  for (const k in HEADERS) headers[k] = HEADERS[k];
  headers['Referer'] = referer || SITE + '/';
  const res = host.fetch({ method: 'GET', url: url, headers: headers });
  if (res.status === 403) throw new Error('91porny 拦了请求（403）');
  if (res.status < 200 || res.status >= 400) throw new Error('91porny 返回 HTTP ' + res.status);
  return res.body || '';
}

function parseCards(html) {
  const out = [];
  const seen = {};
  const re = /<div class="video-elem[^"]*">/g;
  const starts = [];
  let m;
  while ((m = re.exec(html)) !== null) starts.push(m.index);
  for (let i = 0; i < starts.length; i++) {
    const chunk = html.substring(starts[i], i + 1 < starts.length ? starts[i + 1] : starts[i] + 2000);
    const link = chunk.match(/href="(\/(?:vod\/view|videos?\/view(?:hd)?)\/[^"#]+)"/);
    if (!link) continue;
    const code = link[1].replace(/^\/+/, '');
    if (seen[code]) continue;
    seen[code] = 1;
    const bg = chunk.match(/background-image:\s*url\('([^']+)'\)/);
    const dur = chunk.match(/<small class="layer">([^<]*)<\/small>/);
    const titleM = chunk.match(/<a[^>]*class="title[^"]*"[^>]*>([\s\S]*?)<\/a>/);
    let title = titleM ? clean(titleM[1]) : '';
    if (!title) continue;
    out.push({
      sourceId: code,
      title: title,
      cover: bg ? bg[1].replace(/&amp;/g, '&') : '',
      duration: dur ? clean(dur[1]) : ''
    });
  }
  return out;
}

function toDrama(item) {
  const title = item.title || item.sourceId;
  return {
    id: host.dramaId(item.sourceId),
    source: host.source,
    sourceId: item.sourceId,
    title: title,
    name: title,
    desc: item.duration ? '时长 ' + item.duration : '',
    intro: '',
    cover: item.cover || '',
    totalEpisode: 1
  };
}

module.exports = {
  validCategory(category) {
    return !category || category === 'new' || CATEGORIES.some(function (e) { return e.id === category; });
  },

  categories() {
    return CATEGORIES;
  },

  catalogPage(page, category) {
    if (!this.validCategory(category)) throw new Error('没有分类 ' + category);
    const n = Number(page || 1) < 1 ? 1 : Number(page || 1);
    const cate = (!category || category === 'new') ? 'vod' : category;
    const items = parseCards(get('/' + cate + '?page=' + n)).map(toDrama);
    return { items: items, hasMore: items.length >= 20 };
  },

  search(page, query) {
    const kw = clean(query || '');
    if (!kw) return { items: [], hasMore: false };
    const n = Number(page || 1) < 1 ? 1 : Number(page || 1);
    const items = parseCards(get('/search?keywords=' + encodeURIComponent(kw) + '&page=' + n)).map(toDrama);
    return { items: items, hasMore: false };
  },

  detail(sourceId) {
    let key = String(sourceId || '').trim().replace(/^https?:\/\/[^\/]+\//, '').replace(/^\/+/, '');
    if (!key) throw new Error('缺少视频编号');
    if (key.indexOf('/') < 0) key = 'vod/view/' + key;
    const pageUrl = SITE + '/' + key;
    const html = get('/' + key);

    const t = html.match(/<title[^>]*>([\s\S]*?)<\/title>/);
    let title = t ? clean(t[1]) : '';
    title = title.replace(/\s*[-–|]\s*91porny[\s\S]*$/i, '').trim();
    if (!title) {
      const og = html.match(/property="og:title"[^>]+content="([^"]*)"/);
      title = og ? clean(og[1]) : key;
    }
    let cover = '';
    const poster = html.match(/data-poster="([^"]+)"/);
    const og = html.match(/property="og:image[^"]*"[^>]+content="([^"]+)"/);
    cover = poster ? poster[1] : (og ? og[1] : '');
    cover = cover.replace(/&amp;/g, '&');

    const drama = {
      id: host.dramaId(key),
      source: host.source,
      sourceId: key,
      title: title || key,
      name: title || key,
      desc: '',
      intro: '',
      cover: cover,
      totalEpisode: 1
    };
    const chapter = {
      id: host.chapterId(key, 'video'),
      source: host.source,
      title: '正片',
      currentEpisode: 1,
      pageUrl: pageUrl,
      referer: pageUrl
    };
    return { drama: drama, chapters: [chapter] };
  },

  resolveMedia(task) {
    let key = '';
    const fromDrama = String((task && task.dramaId) || '').split(':');
    if (fromDrama.length >= 2) key = fromDrama[1];
    if (!key) {
      const fromChapter = String((task && task.chapter && task.chapter.id) || '').split(':');
      if (fromChapter.length >= 3) key = fromChapter[1];
    }
    if (!key) throw new Error('无法确定视频编号');
    if (key.indexOf('/') < 0) key = 'vod/view/' + key;

    const pageUrl = SITE + '/' + key;
    const html = get('/' + key);
    const tag = html.match(/<video[^>]*id="video-play"[^>]*>/i) || html.match(/<video[^>]*data-src="[^"]*m3u8[^"]*"[^>]*>/i);
    if (!tag) throw new Error('详情页没有播放标签');
    const src = (tag[0].match(/data-src="([^"]+)"/) || [])[1];
    if (!src) throw new Error('没有播放地址');

    let url = src.replace(/&amp;/g, '&');
    if (url.indexOf('//') === 0) url = 'https:' + url;

    return {
      url: url,
      referer: pageUrl,
      quality: 720,
      credentials: { referer: pageUrl, origin: SITE, userAgent: UA }
    };
  }
};
