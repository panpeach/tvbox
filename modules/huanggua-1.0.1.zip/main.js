const siteBase = "https://hgaihub.com";
const userAgent =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1";
const pageSize = 20;

// id 用标签中文名，和站点 tag 一致；空字符串表示全部
const categories = [
  { id: "", name: "全部" },
  { id: "穿越", name: "穿越" },
  { id: "现代", name: "现代" },
  { id: "乱伦", name: "乱伦" },
  { id: "NTR", name: "NTR" },
  { id: "多P", name: "多P" },
  { id: "少妇", name: "少妇" },
  { id: "淫妻", name: "淫妻" },
  { id: "言情", name: "言情" },
  { id: "校园", name: "校园" },
  { id: "玄幻", name: "玄幻" },
  { id: "武侠", name: "武侠" },
  { id: "原创", name: "原创" },
  { id: "母子", name: "母子" },
  { id: "熟女", name: "熟女" },
  { id: "后宫", name: "后宫" },
  { id: "系统", name: "系统" },
  { id: "脑洞", name: "脑洞" },
];

function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function firstNonEmpty(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.trim() !== "") {
      return value.trim();
    }
  }
  return "";
}

function mapString(row, ...keys) {
  if (!isRecord(row)) {
    return "";
  }
  for (const key of keys) {
    const value = row[key];
    if (typeof value === "string") {
      const trimmed = value.trim();
      if (trimmed !== "") {
        return trimmed;
      }
    } else if (typeof value === "number" || typeof value === "boolean") {
      return String(value);
    }
  }
  return "";
}

function atoi(text) {
  return /^[+-]?\d+$/.test(String(text)) ? parseInt(text, 10) : NaN;
}

function resolveUrl(ref) {
  ref = String(ref || "").trim();
  if (ref === "") {
    return "";
  }
  if (ref.startsWith("//")) {
    return "https:" + ref;
  }
  if (ref.startsWith("/")) {
    return siteBase + ref;
  }
  if (/^https?:\/\//i.test(ref)) {
    return ref.replace(/^http:/i, "https:");
  }
  return ref;
}

function apiGet(path) {
  const url = path.startsWith("http") ? path : siteBase + path;
  const response = host.fetch({
    url,
    method: "GET",
    headers: {
      "User-Agent": userAgent,
      Accept: "application/json, text/plain, */*",
      Referer: siteBase + "/",
      Origin: siteBase,
    },
    timeoutMs: 15000,
    limit: 4 << 20,
  });
  if (response.status < 200 || response.status >= 300) {
    throw new Error("黄瓜接口 HTTP " + response.status);
  }
  let body;
  try {
    body = JSON.parse(response.body);
  } catch (error) {
    throw new Error("黄瓜接口返回非 JSON");
  }
  if (!isRecord(body)) {
    throw new Error("黄瓜接口格式异常");
  }
  if (body.status !== undefined && body.status !== 1 && body.status !== true) {
    throw new Error("黄瓜接口失败：" + firstNonEmpty(body.msg, "未知错误"));
  }
  return body.data === undefined ? body : body.data;
}

function dramaFromItem(row) {
  const sourceId = String(
    firstNonEmpty(mapString(row, "id"), mapString(row, "video_id"), mapString(row, "videoId"))
  ).trim();
  if (sourceId === "" || !/^\d+$/.test(sourceId)) {
    return null;
  }
  const title = firstNonEmpty(mapString(row, "title"), mapString(row, "name"));
  if (title === "") {
    return null;
  }
  let cover = resolveUrl(
    firstNonEmpty(
      mapString(row, "cover"),
      mapString(row, "cover_url"),
      mapString(row, "image"),
      mapString(row, "poster")
    )
  );
  if (cover.startsWith("/api/media/")) {
    cover = siteBase + cover;
  }
  const episodes = atoi(
    firstNonEmpty(
      mapString(row, "episode_count"),
      mapString(row, "total_episodes"),
      mapString(row, "totalEpisode"),
      mapString(row, "episodes")
    )
  );
  const score = mapString(row, "score", "rating");
  const hot = mapString(row, "hot", "views", "play_count");
  let views = "";
  if (hot !== "") {
    const n = Number(hot);
    if (!isNaN(n) && n > 0) {
      views = n >= 10000 ? (n / 10000).toFixed(1) + "万次播放" : String(n) + "次播放";
    }
  }
  const tags = [];
  if (Array.isArray(row.tags)) {
    for (const t of row.tags) {
      if (typeof t === "string" && t.trim() !== "") {
        tags.push(t.trim());
      } else if (isRecord(t) && mapString(t, "name") !== "") {
        tags.push(mapString(t, "name"));
      }
    }
  }
  const finished = row.is_finished === true || row.is_finished === 1 || row.is_finished === "1";
  const drama = {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId,
    title,
    name: title,
    desc: firstNonEmpty(mapString(row, "description"), mapString(row, "desc"), mapString(row, "intro")),
    intro: firstNonEmpty(mapString(row, "description"), mapString(row, "desc"), mapString(row, "intro")),
    cover,
    coverUrl: cover,
    totalEpisode: episodes > 0 ? String(episodes) : "",
    episodeCount: episodes > 0 ? String(episodes) : "",
    score: score !== "" ? score : "",
    views,
    releaseStatus: finished ? "finished" : "ongoing",
    badge: finished && episodes > 0 ? "全" + episodes + "集" : episodes > 0 ? "更新至" + episodes + "集" : "",
  };
  if (tags.length > 0) {
    drama.tags = tags;
    drama.categoryName = tags[0];
  }
  return drama;
}

function parseList(data) {
  let items = [];
  if (Array.isArray(data)) {
    items = data;
  } else if (isRecord(data) && Array.isArray(data.items)) {
    items = data.items;
  } else if (isRecord(data) && Array.isArray(data.list)) {
    items = data.list;
  } else if (isRecord(data) && Array.isArray(data.videos)) {
    items = data.videos;
  }
  const result = [];
  const seen = new Set();
  for (const row of items) {
    const drama = dramaFromItem(row);
    if (drama !== null && !seen.has(drama.sourceId)) {
      seen.add(drama.sourceId);
      result.push(drama);
    }
  }
  return result;
}

function hasMoreFrom(data, page, fetched) {
  if (isRecord(data)) {
    if (typeof data.has_more === "boolean") {
      return data.has_more;
    }
    if (typeof data.hasMore === "boolean") {
      return data.hasMore;
    }
    const total = atoi(mapString(data, "total", "total_count", "count"));
    if (total > 0) {
      return page * pageSize < total;
    }
  }
  return fetched >= pageSize;
}

function validCategory(category) {
  return category === "" || categories.some((entry) => entry.id === category);
}

module.exports = {
  validCategory,

  categories() {
    return categories.slice();
  },

  catalogPage(page, category) {
    page = Math.max(1, parseInt(page, 10) || 1);
    category = category === undefined || category === null ? "" : String(category);
    if (!validCategory(category)) {
      throw new Error("内容分类无效");
    }
    let path;
    if (category === "") {
      path = "/api/videos?page=" + page + "&size=" + pageSize;
    } else {
      // 站点 tag 参数不生效，用搜索接口按标签名筛
      path =
        "/api/search?q=" + encodeURIComponent(category) + "&page=" + page + "&size=" + pageSize;
    }
    const data = apiGet(path);
    const items = parseList(data);
    return {
      items,
      hasMore: hasMoreFrom(data, page, items.length),
    };
  },

  search(page, query) {
    page = Math.max(1, parseInt(page, 10) || 1);
    query = String(query || "").trim();
    if (query === "") {
      return { items: [], hasMore: false };
    }
    const path =
      "/api/search?q=" + encodeURIComponent(query) + "&page=" + page + "&size=" + pageSize;
    const data = apiGet(path);
    const items = parseList(data);
    return {
      items,
      hasMore: hasMoreFrom(data, page, items.length),
    };
  },

  detail(sourceId) {
    sourceId = String(sourceId || "").trim();
    if (!/^\d+$/.test(sourceId)) {
      throw new Error("黄瓜剧集 ID 无效");
    }
    const data = apiGet("/api/videos/" + encodeURIComponent(sourceId));
    if (!isRecord(data)) {
      throw new Error("黄瓜详情格式异常");
    }
    const drama = dramaFromItem(data);
    if (drama === null) {
      throw new Error("黄瓜未找到该剧集");
    }
    const chapters = [];
    let episodeList = [];
    if (Array.isArray(data.episodes)) {
      episodeList = data.episodes;
    }
    if (episodeList.length === 0) {
      const total = atoi(mapString(data, "episode_count", "total_episodes")) || 1;
      for (let i = 1; i <= total; i++) {
        episodeList.push({ ep_num: i, title: "第" + i + "集" });
      }
    }
    for (const ep of episodeList) {
      if (!isRecord(ep)) {
        continue;
      }
      const num = atoi(mapString(ep, "ep_num", "episode", "currentEpisode", "index")) || 0;
      if (num < 1) {
        continue;
      }
      const title = firstNonEmpty(mapString(ep, "title", "name"), "第" + num + "集");
      chapters.push({
        id: host.chapterId(sourceId, String(num)),
        source: host.source,
        sourceId,
        title,
        currentEpisode: num,
        pageUrl: siteBase + "/video/" + sourceId + (num > 1 ? "/ep-" + num + "/" : "/"),
      });
    }
    chapters.sort((a, b) => a.currentEpisode - b.currentEpisode);
    return { drama, chapters };
  },

  resolveMedia(task) {
    if (!isRecord(task) || !isRecord(task.chapter)) {
      throw new Error("播放参数无效");
    }
    let sourceId = "";
    const dramaId = String(task.dramaId || "");
    const dramaParts = dramaId.split(":");
    if (dramaParts.length >= 2 && /^\d+$/.test(dramaParts[1])) {
      sourceId = dramaParts[1];
    }
    if (sourceId === "") {
      const chId = String(task.chapter.id || "");
      const chParts = chId.split(":");
      if (chParts.length >= 2 && /^\d+$/.test(chParts[1])) {
        sourceId = chParts[1];
      }
    }
    if (sourceId === "" && task.chapter.sourceId) {
      sourceId = String(task.chapter.sourceId).trim();
    }
    let episode = task.chapter.currentEpisode;
    if (typeof episode === "string") {
      episode = atoi(episode);
    }
    if (!Number.isInteger(episode) || episode < 1) {
      const key = String(task.chapter.id || "").split(":").pop() || "";
      episode = atoi(key) || 1;
    }
    if (!/^\d+$/.test(sourceId)) {
      throw new Error("黄瓜播放剧集 ID 无效");
    }
    const data = apiGet(
      "/api/videos/" + encodeURIComponent(sourceId) + "/play?ep=" + episode
    );
    if (!isRecord(data)) {
      throw new Error("黄瓜播放接口异常");
    }
    let url = firstNonEmpty(
      mapString(data, "video_url"),
      mapString(data, "url"),
      mapString(data, "play_url"),
      mapString(data, "m3u8")
    );
    if (url === "" && isRecord(data.streams)) {
      url = firstNonEmpty(mapString(data.streams, "main"), mapString(data.streams, "hevc"));
    }
    url = resolveUrl(url);
    if (url === "" || (!url.includes(".m3u8") && !url.includes(".mp4"))) {
      throw new Error("黄瓜未返回有效播放地址");
    }
    const result = {
      url,
      referer: siteBase + "/",
      quality: 720,
    };
    const duration = atoi(mapString(data, "duration"));
    if (duration > 0) {
      result.durationMs = duration * 1000;
    }
    return result;
  },
};
